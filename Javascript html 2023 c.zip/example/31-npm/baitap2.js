var markdown = require( "markdown" ).markdown;
console.log( markdown.toHTML( "Hello *Coders.Tokyo*!" ) );