var passwordGenerator = require('password-generator');
console.log(passwordGenerator(8));